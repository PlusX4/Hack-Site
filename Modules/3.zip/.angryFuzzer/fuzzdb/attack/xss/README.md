test.xxe - requested by some payloads from fuzzdb github repo raw filepath<br>
xss-rsnake.fuzz.txt - rsnake's classic fuzzfile, modified to load http://xss.rocks test files<br>
xss-other.fuzz.txt 	- newer payloads from various sources: my own testing, interesting filter bypassed found in the wild, etc. <br>
xss-uri.fuzz.txt - URI abuse test cases<br>
XSSPolyglot.fuzz.txt - from https://github.com/0xsobky/HackVault/wiki/Unleashing-an-Ultimate-XSS-Polyglot - check the page for filter evasions and other interesting stuff
<br>


HTML5 Cheatsheet
* https://html5sec.org/
* https://github.com/cure53/H5SC

<br>

WASC Script Mapping Project
* http://projects.webappsec.org/w/page/13246958/Script%20Mapping


