<h1>FuzzDB Attack Patterns</h1>

**WAF Evasion** <br>
* <a href=../master/docs/attack-docs/waf-bypass/regexp-security-cheatsheet.md>Regexp security Cheatsheet</a> 
* Source: https://github.com/attackercan/regexp-security-cheatsheet/blob/master/README.md 
