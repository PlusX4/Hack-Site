References:

http://ha.ckers.org/response-splitting.html

