#!/usr/bin/env python
# -*- coding: UTF-8 -*-
R = ("\033[31m")
W = ("\033[0;1m")
B = ("\033[35m")
G = ("\033[32m")
glp = ("\033[2m")
Y = ("\033[33;1m")

from urllib2 import Request, urlopen, URLError, HTTPError

def Space(j):
	i = 0
	while i<=j:
		print " ",
		i+=1


def findAdmin():
	f = open("link.txt","r");
	link = raw_input( G + "[+] Enter The Website ^> ")
	print "\n\nAvilable links : \n"
	while True:
		sub_link = f.readline()
		if not sub_link:
			break
		req_link = "http://"+link+"/"+sub_link
		req = Request(req_link)
		try:
			response = urlopen(req)
		except HTTPError as e:
			continue
		except URLError as e:
			continue
		else:
			print "OK => ",req_link

def Credit():
	Space(9); print( R + ''' 
	    _       _           _         ____                  _ 
	   / \   __| |_ __ ___ (_)_ __   |  _ \ __ _ _ __   ___| |
	  / _ \ / _` | '_ ` _ \| | '_ \  | |_) / _` | '_ \ / _ \ |
	 / ___ \ (_| | | | | | | | | | | |  __/ (_| | | | |  __/ |
	/_/   \_\__,_|_| |_| |_|_|_| |_| |_|   \__,_|_| |_|\___|_|

	''')
		
Credit()
findAdmin()